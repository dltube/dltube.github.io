import sys
import urllib
import urlparse
import xbmcgui
import xbmcplugin
import xbmc
import xbmcaddon
import requests
base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
args = urlparse.parse_qs(sys.argv[2][1:])
addon = xbmcaddon.Addon("plugin.video.dltube")
xbmcplugin.setContent(addon_handle, 'movies')

def build_url(query):
	return base_url + '?' + urllib.urlencode(query)
def isac():


	try:
		addon = xbmcaddon.Addon("plugin.video.dltube")
		ip = addon.getSetting('ip')
		if ip == '':
			return False
		requests.get('http://'+ip, timeout=5)
	except:
		return False
		#urllib.request.urlopen('http://'+ip) 
	return ip


def savac(ip):
	addon = xbmcaddon.Addon("plugin.video.dltube")
	addon.setSetting('ip',ip)
def getusersearch():
	kb = xbmc.Keyboard('default', 'heading')
	kb.setDefault('')
	kb.setHeading('Enter ip')
	kb.setHiddenInput(False)
	kb.doModal()
	if (kb.isConfirmed()):
		search_term = kb.getText()
		return search_term
	else:
		return False
ip = isac()
def genpage(urll):
	global ip
	jso = requests.get('http://'+ip+urll).json()
	for i, js in enumerate(jso):
		if js['link'][0] == '/':
			link = '/x'+js['link'][1:]
		else:
			link = '/x'+js['link']

		url = build_url({'mode': 'page', 'ur':link})
		l = str(i)
		if 'text' in js:
			l = js['text']
		if 'play' in url:

			li = xbmcgui.ListItem(l, iconImage="http://"+ip+js['img'])
			
			li.setInfo('video', {'title':l})
			li.setProperty('IsPlayable', 'true')
			xbmcplugin.addDirectoryItem(handle=addon_handle, url='http://'+ip+link.replace('xplay','gvid'), listitem=li)
		else:
			li = xbmcgui.ListItem(l,iconImage="http://"+ip+js['img'])
			xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
										listitem=li, isFolder=True)

mode = args.get('mode', None)
ur = args.get('ur', '/x')
if mode is None:
	
	if ip == False:
		url = build_url({'mode': 'ref'})
		li = xbmcgui.ListItem('refresh')
		xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
									listitem=li, isFolder=True)

		url = build_url({'mode': 'neip'})
		li = xbmcgui.ListItem('add ip')
		xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
									listitem=li, isFolder=True)

		xbmcplugin.endOfDirectory(addon_handle)
	else:
		genpage('/x')

		xbmcplugin.endOfDirectory(addon_handle)

elif mode[0] == 'neip':

	ip = getusersearch()
	if ip != False:
		savac(ip)
	if ip == False:
		url = build_url({'mode': 'ref'})
		li = xbmcgui.ListItem('refresh')
		xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
									listitem=li, isFolder=True)

		url = build_url({'mode': 'neip'})
		li = xbmcgui.ListItem('add ip')
		xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
									listitem=li, isFolder=True)

		xbmcplugin.endOfDirectory(addon_handle)
	else:
		genpage('/x')

		xbmcplugin.endOfDirectory(addon_handle)
elif mode[0] == 'ref':
	ip = isac()
	if ip == False:
		url = build_url({'mode': 'ref'})
		li = xbmcgui.ListItem('refresh')
		xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
									listitem=li, isFolder=True)

		url = build_url({'mode': 'neip'})
		li = xbmcgui.ListItem('add ip')
		xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
									listitem=li, isFolder=True)

		xbmcplugin.endOfDirectory(addon_handle)
	else:
		genpage('/x')

		xbmcplugin.endOfDirectory(addon_handle)
elif mode[0] == 'page':
	urll=ur[0]
	if 'xplay' in urll:
    	
		xbmc.Player().play('http://'+ip+urll.replace('xplay','gvid'))
	else:
		genpage(urll)
		xbmcplugin.endOfDirectory(addon_handle)
elif mode[0] == 'vid':
	xbmc.Player().play('http://'+ip+args.get('video', None)[0].replace(r'%2F','/'))